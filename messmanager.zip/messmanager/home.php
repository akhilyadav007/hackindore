<?php
session_start();
mysql_connect('localhost','root','');
mysql_select_db('messmnager');
?>
<!DOCTYPE html>
<meta charset="UTF-8">
<html>
<head>
<title> Home </title>
</head>
<body align="center">
<style>
	html,body
	{
		margin: 0;
		padding: 0;
	}
	.header
	{
		position: relative;
		background-color: black;
		color: white;
		margin: 0;
		padding: 10px;
	}
	h1
	{
		height: 50px; 
		float-left: 55px;
	}
</style>
<div class="header">
	<h1 align="center">Student Voting Result</h1>
</div>
<br>
<?php
if($_SESSION['username'] != "")
{
?>
<a href="logout.php"><img src="image/logout.png" value="Logout" width="110px" height="50px"></a>
<?php
}
else
{
?>
<a href="login.php"><img src="image/login.png" value="Login" width="110px" height="50px"></a>	
<?php
}
?>
<?php
$query = mysql_query("SELECT * FROM votes LEFT JOIN candidate ON candidate.candidate_id = votes.candidate_id LEFT JOIN student ON student.student_id = candidate.student_id LEFT JOIN position ON position.position_id = candidate.position_id WHERE votes.student_id = " . $_SESSION['student_id'] . "") or die(mysql_error());
?>
<?php if(mysql_num_rows($query) > 0) { ?>
<table align="center" border="1">
<br>
<br>
	<thead>
		<tr>
			<th>Name</th>
			<th>Position</th>
		</tr>
	</thead>
	<tbody>
		<?php 	
			while($row = mysql_fetch_array($query))
			{ 
		?>
		<tr>
			<td><?php echo $row['firstname']; ?> <?php echo $row['middlename']; ?> <?php echo $row['lastname']; ?></td>
			<td><?php echo $row['position_title']; ?></td>
		</tr>
		<?php
			}
		?>
	</tbody>
</table>		
<?php } else { ?>
<p style="text-align:center;">You have not voted any candidates yet!</p>
<?php } ?>
</body>
</html>
