<?php
session_start();
mysql_connect('localhost','root','');
mysql_select_db('messmanager');
if($_SESSION['userid'] == "")
{
	header("location: index.php");
}
?>
<form method="post" action="">
<input type="text" name="position_title" value="" />
<input type="submit" name="submit" value="Add Position" />
</form>

<?php
if(isset($_POST['submit']))
{	
	mysql_query("INSERT INTO position (position_title) VALUES ('".ucwords($_POST['position_title'])."')") or die(mysql_error());
	
	echo "Position has been added successfully!";
}
?>

<?php
$getPositionsList = mysql_query("SELECT * FROM position") or die(mysql_error());

if(mysql_num_rows($getPositionsList) > 0)
{
?>
<table border="1" cellpadding="5">
	<thead>
		<tr>
			<th>Title</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
		<?php while($row = mysql_fetch_array($getPositionsList)) { ?>
		<tr>
			<td><?php echo $row['position_title']; ?></td>
			<td><a href="editposition.php?position_id=<?php echo $row['position_id']; ?>">Edit</a> | <a href="deleteposition.php?position_id=<?php echo $row['position_id']; ?>">Delete</a></td>
		</tr>
		<?php } ?>
	</tbody>
</table>	
<?php 
}
?>

