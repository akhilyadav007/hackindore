<?php
session_start();
mysql_connect('localhost','root','');
mysql_select_db('vote');
if($_SESSION['username'] == "")
{
	header("location: login.php");
}
if($_SESSION['status'] != 0)
{
	header("location: home.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title> Candidate </title>
</head>
<body>
<style>
	body {
  background-image: url( breakfast.jpg)
}

nav {
  max-width: 960px;
  mask-image: linear-gradient(90deg, rgba(255, 255, 255, 0) 0%, #ffffff 25%, #ffffff 75%, rgba(255, 255, 255, 0) 100%);
  margin: 0 auto;
  padding: 50px 0;
}
 
nav ul {
  text-align: center;
  background: linear-gradient(90deg, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.2) 25%, rgba(255, 255, 255, 0.2) 75%, rgba(255, 255, 255, 0) 100%);
  width: 100%;
  box-shadow: 0 0 25px rgba(0, 0, 0, 0.1), inset 0 0 1px rgba(255, 255, 255, 0.6);
}
 
nav ul li {
  display: inline-block;
}
 
nav ul li a {
  padding: 20px;
  font-family: "Roboto";
  color: rgba(0, 0, 0, 0.5);
  text-shadow: 1px 1px 1px rgba(255, 255, 255, 0.4);
  font-size: 25px;
  text-decoration: none;
  display: block;
}
 
nav ul li a:hover {
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1), inset 0 0 1px rgba(255, 255, 255, 0.6);
  background: rgba(255, 255, 255, 0.1);
  color: rgba(0, 0, 0, 0.7);
}
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>
<div class="header">
<nav>
  <ul>
    <li>
      <a href="candidate.php">BreakFast</a>
    </li>
    <li>
      <a href="lunch.php">Lunch</a>
    <li>
      <a href="#">Snacks</a>
    </li>
    <li>
      <a href="#">Dinner</a>
    </li>
 <li>
     <a href="http://localhost/messmanager/index.php">Logout</a>
    </li>
  </ul>
</nav>

</div>

<div class="container">
  <h2>BREAKFAST(Time : 8:00AM to 10:00AM)</h2>           
<center>  
<table>
    <thead>
      <tr>
        <th>Day</th>
        <th>Menu</th>
       
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Monday</td>
        <td>Idli-Sambhar</td>
        
      </tr>

	<tr>
        <td>Tuesday</td>
        <td>Poha-Jalebi</td>
        
      </tr>

	<tr>
        <td>Wednesday</td>
        <td>Vada-pav</td>
        
      </tr>

	<tr>
        <td>Thursday</td>
        <td>Masala-dosa</td>
        
      </tr>

	<tr>
        <td>Friday</td>
        <td>Aaloo-bada</td>
        
      </tr>

	<tr>
        <td>Saturday</td>
        <td>Sandwich</td>
        
      </tr>

	
	
      
    </tbody>
  </table>
</center>
</div>

<br>
<br>
<br>
<br>
<br>
<br>
<?php
$query = mysql_query("SELECT * FROM position ORDER BY position_id ASC") or die(mysql_error());

if(mysql_num_rows($query) > 0)
{
?>
<form align="center" method = "post" action="processvote.php">
<table align="center" colspan="2">
	<tbody>
<h3>If you are interested...then choose the option in front of your name.....</h3>
	<?php 
	while($row = mysql_fetch_array($query))
	{ 
	$candidates = mysql_query("SELECT * FROM candidate LEFT JOIN student ON student.student_id = candidate.student_id WHERE candidate.position_id = '".$row['position_id']."'") or die(mysql_error());
	?>
		<tr>
			<td>
					
				<?php 
				if(mysql_num_rows($candidates) > 0)
				{ 
					while($stud = mysql_fetch_array($candidates))
					{ 
				?>
					<input type="radio" name="position_<?php echo $row['position_id']; ?>" value="<?php echo $stud['candidate_id']; ?>"> <?php echo $stud['firstname'] . " " . $stud['middlename'] . " " . $stud['lastname']; ?>
				<?php 
					}
				} 
				?>
			</td>
		</tr>
	<?php 
	} 
	?>
	</tbody>
</table>
<br><br>
<td><input type="submit" name="vote" value="SUBMIT"></td>
<td><input type="reset" name="reset" value="RESET"></td>
<br>
<br>
</form>
<?php } ?>

</body>
</html>