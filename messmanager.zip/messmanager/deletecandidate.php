<?php
session_start();
mysql_connect('localhost','root','');
mysql_select_db('messmanager');
if($_SESSION['userid'] == "")
{
	header("location: index.php");
}
mysql_query("DELETE FROM candidate WHERE candidate_id = '".$_GET['candidate_id']."'") or die(mysql_error());
mysql_query("DELETE FROM votes WHERE candidate_id = '".$_GET['candidate_id']."'") or die(mysql_error());

header("location: addcandidate.php");
?>