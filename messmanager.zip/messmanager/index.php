<!DOCTYPE html>
<meta charset="UTF-8">
<html>
<head>
<title> Log-In </title>
<style type="text/css">
      body {
		
        padding-top: 40px;
        padding-bottom: 40px;
      }
      .sidebar-nav {
        padding: 9px 0;
      }
 
	fieldset 
		{  	
			text-align:center; width: 540px;
			background-size: 10% 20%;
			margin-left:30%;
			margin-top:150px;
			margin-bottom:150px;
			border-radius: 6px;
			box-shadow: 2px 4px 8px rgba(0,0,0,.6) 
		} 
	form INPUT 
		{
			width:110px;
			height:60px;
			padding: 10px;
		}
	body
		{                background-size: 100% 100%;
			background-repeat: no-repeat;
			background-image:url(image/front1.jpg);
		}
		
</style>
</head>
<body>
<fieldset>
<form method="post" action="">
<h1 style="font-family:Parkavenue, cursive;font-size:250%;"><i><b><center>MY CANTEEN</b></i></h1></center>
		<br>
<h1>Log-In As</h1>
<br>
<div id="container" align="center">
<table>
<tr>
<td colspan="2" align="right"><a href="login.php"><img src="image/student.png" value="Student" width="110px" height="60px"></a></td>
<td colspan="2" align="left"><a href="adminlogin.php"><img src="image/admin.png" value="Admin" width="110px" height="60px"></a></td>
</tr>
<br>
</table>
<br>
<br>
<br>
</form></fieldset>
</div>
</body>
</html>
