<?php
session_start();
mysql_connect('localhost','root','');
mysql_select_db('messmanager');
if($_SESSION['userid'] == "")
{
	header("location: abc.php");
}
?>
<!DOCTYPE html>
<meta charset="UTF-8">
<html>
<head>
<title> Result </title>
</head>
<body align="left">
<style>
	html,body{align:left;
	background-size: 100% 120%;
			background-repeat: no-repeat;
			background-image:url(food2.jpg);
		
		margin: 0;
		padding: 0;
	}
	.header
	{
		position: relative;
		margin: 0;
		padding: 10px;
	}
	h1
	{
		height: 50px; 
	}
</style>
<div class="header">
	<h1 align="left">Student Voting Result</h1>
</div>
<br>
<?php
if($_SESSION['username'] != "")
{
?>
<a href="logout.php"><img src="image/logout.png" value="Logout" width="110px" height="50px"></a>
<?php
}
else
{
?>
<a href="login.php"><img src="image/login.png" value="Login" width="110px" height="50px"></a>	
<?php
}
?>
<?php
$query = mysql_query("SELECT *, (SELECT COUNT(*) FROM votes WHERE votes.candidate_id = candidate.candidate_id) as votecount FROM candidate LEFT JOIN student ON student.student_id = candidate.student_id LEFT JOIN position ON position.position_id = candidate.position_id ORDER BY position.position_id ASC") or die(mysql_error());
?>
<table align="left" border="1">

<br>
	<thead>
		<tr>
			<th>Name</th>
			<th>Position</th>
			<th>Vote Count</th>
		</tr>
	</thead>
	<tbody>
		<?php 
		if(mysql_num_rows($query) > 0)
		{	
			while($row = mysql_fetch_array($query))
			{ 
		?>
		<tr>
			<td><?php echo $row['firstname']; ?> <?php echo $row['middlename']; ?> <?php echo $row['lastname']; ?></td>
			<td><?php echo $row['position_title']; ?></td>
			<td><?php echo $row['votecount']; ?></td>
		</tr>
		<?php
			}
		}
		?>
	</tbody>
</table>
</body>
</html>
