<?php
session_start();
mysql_connect('localhost','root','');
mysql_select_db('messmanager');
if($_SESSION['userid'] == "")
{
	header("location: index.php");
}
$queryStudentsList = mysql_query("SELECT * FROM student ORDER BY firstname ASC") or die(mysql_error());
$queryPositionsList = mysql_query("SELECT * FROM position ORDER BY position_id ASC") or die(mysql_error());

?>
<form method="post" action="">
<select name="student_id" required>
	<option value="">Select Student</option>
	<?php while($row = mysql_fetch_array($queryStudentsList)){ ?>
	<option value="<?php echo $row['student_id']; ?>"><?php echo $row['firstname']; ?> <?php echo $row['middlename']; ?> <?php echo $row['lastname']; ?></option>
	<?php } ?>
</select>
<select name="position_id" required>
	<option value="">Select Position</option>
	<?php while($row = mysql_fetch_array($queryPositionsList)){ ?>
	<option value="<?php echo $row['position_id']; ?>"><?php echo $row['position_title']; ?></option>
	<?php } ?>
</select>
<input type="submit" name="submit" value="Add Candidate" />
</form>

<?php
if(isset($_POST['submit']))
{
	$checkCandidate = mysql_query("SELECT * FROM candidate WHERE student_id = '".$_POST['student_id']."' AND position_id = '".$_POST['position_id']."'") or die(mysql_error());
	
	$validateData = mysql_fetch_assoc($checkCandidate);
	
	if(!empty($validateData))
	{
		echo "Student has already been added as a candidate!";
	}
	else
	{
		mysql_query("INSERT INTO candidate (position_id,student_id) VALUES ('".$_POST['position_id']."','".$_POST['student_id']."')") or die(mysql_error());
	
		echo "Student has been added successfully!";
	}
}
?>

<?php
$getCandidateList = mysql_query("SELECT * FROM candidate LEFT JOIN position ON position.position_id = candidate.position_id LEFT JOIN student ON student.student_id = candidate.student_id") or die(mysql_error());

if(mysql_num_rows($getCandidateList) > 0)
{
?>
<table border="1" cellpadding="5">
	<thead>
		<tr>
			<th>Name</th>
			<th>Position</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
		<?php while($row = mysql_fetch_array($getCandidateList)) { ?>
		<tr>
			<td><?php echo $row['firstname']; ?> <?php echo $row['middlename']; ?> <?php echo $row['lastname']; ?></td>
			<td><?php echo $row['position_title']; ?></td>
			<td><a href="deletecandidate.php?candidate_id=<?php echo $row['candidate_id']; ?>">Delete</a></td>
		</tr>
		<?php } ?>
	</tbody>
</table>	
<?php 
}
?>