<?php
session_start();
mysql_connect('localhost','root','');
mysql_select_db('messmanager');
if($_SESSION['username'] == "")
{
	header("location: login.php");
}
if($_SESSION['status'] != 0)
{
	header("location: home.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title> Candidate </title>
</head>
<body>
<style>
<style type="text/css">
      body {
		background-color = #D6ACE6;
        padding-top: 60px;
        padding-bottom: 40px;
      }
      .sidebar-nav {
        padding: 9px 0;
      }
    </style>
    <link href="main/css/bootstrap-responsive.css" rel="stylesheet">

<link href="style.css" media="screen" rel="stylesheet" type="text/css" />
</head>
<body>
    <div class="container-fluid">
      <div class="row-fluid">
		<div class="span4">
		</div>
	
</div>
<div id="login">

<form action="login.php" method="post">

			<font style=" font:bold 44px 'Aleo'; color:#fff;"><center>My Canteen</center></font>
		<br>

		

		<input style="height:40px;" type="text" name="username" Placeholder="Username" required/><br><br><br><br><br>

	<input type="password" style="height:40px;" name="password" Placeholder="Password" required/><br>
		</div>
		<div class="qwe">
		 <br><br><button class="btn btn-large btn-primary btn-block pull-right" href="dashboard.html" type="submit"><i class="icon-signin icon-large">
		</i> Login</button><br><br>
		<span>&nbsp;</span><span style="font-size: 11px; font-weight: normal; width: 170px; text-align: left;">Not yet a member? Register <a rel="facebox" href="register.php">Here</a><br>Forgot Password? click <a href="#" onClick="MyWindow=window.open('pwordrecover.php','MyWindow','toolbar=no,location=no,directories=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=300,height=200'); return false;">Here</a></span><br><br>
<span>&nbsp;</span>


		
	html,body
	{
		margin: 0;
		padding: 0;
	}
	.header
	{
		position: relative;
		background-color: black;
		color:white;
		margin: 0;
		padding: 10px;
	}
	h1
	{
		height: 50px; 
		float-left: 55px;
	}
</style>
<div class="header">
</div>
<?php
if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
	foreach($_SESSION['ERRMSG_ARR'] as $msg) {
		echo '<div style="color: red; text-align: center;">',$msg,'</div><br>'; 
	}
	unset($_SESSION['ERRMSG_ARR']);
}
?>
<form align="center" method = "post" action="processvote.php">
<table align="center" colspan="2">
	
<br><br>
<td><input type="submit" name="vote" value="VOTE"></td>
<td><input type="reset" name="reset" value="RESET"></td>
<br>

</div>
</div>
</div>
</div>
</body>
</html>
