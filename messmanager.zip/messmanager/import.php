<?php  
$connect = mysql_connect("localhost","root",""); 
mysql_select_db("messmanager",$connect);

if(isset($_FILES['csv'])){
if ($_FILES['csv']['size'] > 0) { 

    $file = $_FILES['csv']['tmp_name']; 
    $handle = fopen($file,"r"); 
    do { 
        if ($data[0]) { 
            mysql_query("INSERT INTO student (username, password, firstname, middlename, lastname) VALUES 
                ( 
                    '".addslashes($data[0])."', 
                    '".addslashes($data[1])."', 
					'".addslashes($data[2])."', 
					'".addslashes($data[3])."', 
					'".addslashes($data[4])."'
                ) 
            "); 
        } 
    } while ($data = fgetcsv($handle,1000,",",'"')); 

}
}

if(isset($_FILES['csvposition'])){
if ($_FILES['csvposition']['size'] > 0) { 

    $file = $_FILES['csvposition']['tmp_name']; 
    $handle = fopen($file,"r"); 
    do { 
        if ($data[0]) { 
            mysql_query("INSERT INTO candidate (student_id,position_id) VALUES 
                ( 
                    '".addslashes($data[0])."',
                    '".addslashes($data[1])."'
                ) 
            "); 
        } 
    } while ($data = fgetcsv($handle,1000,",",'"')); 

}
}
?>