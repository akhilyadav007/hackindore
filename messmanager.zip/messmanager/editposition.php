<?php
session_start();
mysql_connect('localhost','root','');
mysql_select_db('messmanager');
if($_SESSION['userid'] == "")
{
	header("location: index.php");
}
$getData = mysql_query("SELECT * FROM position WHERE position_id = '".$_GET['position_id']."'") or die(mysql_error());
$data = mysql_fetch_assoc($getData);
?>
<form method="post" action="">
<input type="text" name="position_title" value="<?php echo $data['position_title']; ?>" />
<input type="submit" name="submit" value="Update Position" />
</form>
<?php
if(isset($_POST['submit']))
{	
	mysql_query("UPDATE position SET position_title = '".ucwords($_POST['position_title'])."' WHERE position_id = '".$_GET['position_id']."'") or die(mysql_error());
	
	header("location: addposition.php");
}
?>