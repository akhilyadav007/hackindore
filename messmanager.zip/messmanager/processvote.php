<html>
<body>
<script>
alert("Successfull....Your response are recorded.");
</script>
<a href="http://localhost/votingsystem2/index.php">ok</a>
</body>
</html>
<?php

session_start();
mysql_connect('localhost','root','');
mysql_select_db('messmanager');

if(isset($_POST['messmanager']))
{
	$query = mysql_query("SELECT * FROM position ORDER BY position_id ASC") or die(mysql_error());

	if(mysql_num_rows($query) > 0)
	{
		while($row = mysql_fetch_array($query))
		{
			$position = $_POST['position_' . $row['position_id']];
			mysql_query("INSERT INTO votes (candidate_id,student_id) VALUES ('$position','".$_SESSION['student_id']."')") or die(mysql_error());
		}
	}
	$_SESSION['checkVote'] = 1;
	header("location: home.php");
}
?>