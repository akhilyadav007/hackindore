<?php
session_start();
mysql_connect('localhost','root','');
mysql_select_db('messmanager');
if($_SESSION['userid'] == "")
{
	header("location: index.php");
}
mysql_query("DELETE FROM position WHERE position_id = '".$_GET['position_id']."'") or die(mysql_error());

header("location: addposition.php");
?>